﻿using Membership.Api.DtosModels;
using Membership.Api.EFRepo.DbContexts;
using Membership.Api.EFRepo.EFModels;
using Membership_Api.Repository.Contract;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Membership_Api.Repository.Services
{
    public class AuthRepo : IAuthRepo
    {
        private readonly MembershipdbContext _context;
        public AuthRepo(MembershipdbContext context)
        {
            _context = context;

        }

        public async Task<bool> Delete(int Id)
        {
            try
            {
                var user = await _context.CustomerDetails.FirstOrDefaultAsync(x => x.Id == Id);
                if (user == null) throw new Exception("User is null");
                var isDeleted = _context.CustomerDetails.Remove(user);

                _context.SaveChanges();

                return true;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /* public Task<CustomerDetail> Register(DCustomerDetails customerDetails)
         {
             throw new System.NotImplementedException();
         }*/

        /* public Task<AdminDetails> Login(DAdminDetails AdminDetails)
         {
             throw new System.NotImplementedException();
         }*/

        public async Task<IEnumerable<CustomerDetail>> GetCustomerDetailsAsync()
        {
            try
            {
                var _users = await _context.CustomerDetails.ToListAsync();
                return _users;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<CustomerDetail> RegisterAsync(CustomerDetail customerDetail)
        {
            await _context.CustomerDetails.AddAsync(customerDetail);
            await _context.SaveChangesAsync();
            return customerDetail;
        }




        public async Task<bool> Update(int Id, CustomerDetail dcustomerDetails)
        {
            bool updCustomerDetail;
            try
            {
                dcustomerDetails.Id= Id;
                _context.Entry(dcustomerDetails).State = EntityState.Modified;
                await _context.SaveChangesAsync();
                updCustomerDetail = true;

            }
            catch (Exception )
            {
                throw new Exception();

            }
            return updCustomerDetail;
        }

        public async Task<CustomerDetail> Login(string username, string password)
        {

            var users = await _context.CustomerDetails.Where(x => x.UserName == username && x.Password == password && x.IsActive == true).FirstOrDefaultAsync();

            if (users == null)
            {
                throw new Exception ();
            }
            return users;
        }

        
    }
}










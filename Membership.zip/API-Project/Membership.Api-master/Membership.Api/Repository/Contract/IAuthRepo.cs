﻿using Membership.Api.EFRepo.EFModels;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace Membership_Api.Repository.Contract
{
    public interface IAuthRepo
    {
        //Task<CustomerDetail> Register(DCustomerDetails customerDetails);
        Task<IEnumerable<CustomerDetail>> GetCustomerDetailsAsync(); //DB Model
        Task<CustomerDetail> RegisterAsync(CustomerDetail customerDetail);
        Task<bool> Delete(int id);
        Task<bool> Update(int Id,CustomerDetail customerDetail);
        Task<CustomerDetail> Login(string userName, string password);
    }
}
    


﻿using AutoMapper;
using Membership.Api.DtosModels;
using Membership.Api.EFRepo.EFModels;
using Membership_Api.Repository.Contract;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Membership.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthRepo _auth;
        private readonly IMapper _mapper;
       

        public AuthController(IAuthRepo auth, IMapper mapper)
        {
            _auth = auth;
            _mapper = mapper;

        }




        [HttpGet("UserDetais")]
        public async Task<IEnumerable<CustomerDetail>> GetUserDetais()

        {
            try
            {
                var _users = await _auth.GetCustomerDetailsAsync();
                return _users;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        [HttpPost("Register")]
        public async Task<IActionResult> Register(DCustomerDetails dCustomerDetails)
        {
            var _userMapper = _mapper.Map<CustomerDetail>(dCustomerDetails);

            var register = await _auth.RegisterAsync(_userMapper);
            return Ok(register);
        }

        [HttpDelete("DeleteById/{id}")]
        public async Task<IActionResult> DeleteById(int id)
        {
            bool deleteUser;
            try
            {

                deleteUser = await _auth.Delete(id);


            }
            catch (Exception) { throw new Exception(); }
            if (deleteUser)
            {
                return StatusCode(201);
            }
            else
            {
                return BadRequest();
            }
        }

        [HttpPut("PutById/{id}")]
        public async Task<IActionResult> Update(int id, DCustomerDetails dcustomerDetails)
        {
            bool _userUpdate;
            try

            {

                var userToUpdate = _mapper.Map<CustomerDetail>(dcustomerDetails);
                _userUpdate = await _auth.Update(id, userToUpdate);
            }
            catch (Exception) { throw new Exception(); }
            if (_userUpdate)
            {
                return Ok(_userUpdate);
            }
            else
            {
                return BadRequest();
            }
        }

            [HttpPost("login")]

            public async Task<IActionResult> Login(LoginAuthDto loginAuthDto)
            
        {

                var userRepoValue = await _auth.Login(loginAuthDto.LoginName,loginAuthDto.Password);




                return Ok(userRepoValue);


        }
        }
    }



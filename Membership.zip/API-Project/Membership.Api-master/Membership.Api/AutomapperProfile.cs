﻿using AutoMapper;

namespace Membership.Api
{
    public class AutomapperProfile:Profile
    {
        public AutomapperProfile()
        {
            CreateMap<Membership.Api.EFRepo.EFModels.CustomerDetail,Membership.Api.DtosModels.DCustomerDetails>().ReverseMap();
           
        }
    }
}

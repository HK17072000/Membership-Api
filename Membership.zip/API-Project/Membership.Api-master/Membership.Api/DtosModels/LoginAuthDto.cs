﻿namespace Membership.Api.DtosModels
{
    public class LoginAuthDto
    {
        public string Password { get; set; }
        public string LoginName { get; set; }
    }
}
